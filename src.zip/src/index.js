import React from 'react';
import ReactDOM from 'react-dom';
import Doc from './sub';
import Box from './para';
import Cards from './list';
import Box3 from './top';
import App from "./App";
import Align from "./coalign";
import Trial from "./trial";
ReactDOM.render(
<>
<App/>,
<Box3/>,
<Box/>,
<Trial/>,
<Align/>,
<Doc/>,
</>,
document.getElementById("root"));






 
